import React, { Component } from "react";
import { Col, Container, Row } from "react-bootstrap";
import "./App.css";
import Formulir from "./components/Form";
import NavbarComponen from "./components/NavbarComponen";
import Tabel from "./components/Tabel";

export default class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      pasien: [],
      nama: "",
      jeniskelamin: "Laki-Laki",
      alamat: "",
      id: "",
    };
  }
  handleChange = (event) => {
    this.setState({
      [event.target.name]: event.target.value,
    });
  };
  handleSubmit = (event) => {
    event.preventDefault();
    if (this.state.id === "") {
      this.setState({
        pasien: [
          ...this.state.pasien,
          {
            id: this.state.pasien.length + 1,
            nama: this.state.nama,
            jeniskelamin: this.state.jeniskelamin,
            alamat: this.state.alamat,
          },
        ],
      });
    } else {
      const pasienTidakDipilih = this.state.pasien
        .filter((pasien) => pasien.id !== this.state.id)
        .map((filterPasien) => {
          return filterPasien;
        });
      this.setState({
        pasien: [
          ...pasienTidakDipilih,
          {
            id: this.state.pasien.length + 1,
            nama: this.state.nama,
            jeniskelamin: this.state.jeniskelamin,
            alamat: this.state.alamat,
          },
        ],
      });
    }
    this.setState({
      nama: "",
      jeniskelamin: "Laki-Laki",
      alamat: "",
      id: "",
    });
  };
  editData = (id) => {
    const pasienEdit = this.state.pasien
      .filter((pasien) => pasien.id === id)
      .map((filterPasien) => {
        return filterPasien;
      });
    this.setState({
      nama: pasienEdit[0].nama,
      jeniskelamin: pasienEdit[0].jeniskelamin,
      alamat: pasienEdit[0].alamat,
      id: pasienEdit[0].id,
    });
  };
  hapusData = (id) => {
    const pasienBaru = this.state.pasien
      .filter((pasien) => pasien.id !== id)
      .map((filterPasien) => {
        return filterPasien;
      });
    this.setState({
      pasien: pasienBaru,
    });
  };
  render() {
    return (
      <Container
        fluid
        className="py-md-5 px-md-5 bg-secondary text-white"
        style={{ height: "auto" }}
      >
        <NavbarComponen />
        <Row className="justify-content-center">
          <Col md={5} className="">
            <Formulir
              {...this.state}
              handleChange={this.handleChange}
              handleSubmit={this.handleSubmit}
            />
          </Col>
          <Col md={{ span: 5, offset: 1 }} className="">
            <Tabel
              pasien={this.state.pasien}
              editData={this.editData}
              hapusData={this.hapusData}
            />
          </Col>
        </Row>
      </Container>
    );
  }
}
